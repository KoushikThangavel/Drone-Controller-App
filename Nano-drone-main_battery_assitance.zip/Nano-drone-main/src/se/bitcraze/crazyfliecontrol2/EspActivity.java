
package se.bitcraze.crazyfliecontrol2;

import static se.bitcraze.crazyfliecontrol2.EspUdpDriver.DEVICE_ADDRESS;
import static se.bitcraze.crazyfliecontrol2.EspUdpDriver.DEVICE_PORT;
//import static se.bitcraze.crazyfliecontrol2.EspUdpDriver.ack_arm;
import static se.bitcraze.crazyfliecontrol2.EspUdpDriver.isDroneConnected;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;

import com.espressif.espdrone.android.R;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Locale;
import android.speech.tts.TextToSpeech;
import android.widget.ToggleButton;


import android.widget.PopupWindow;
import android.view.LayoutInflater;
import android.os.Handler;


import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;



public abstract class EspActivity extends AppCompatActivity {
    private MutableLiveData<String> mBroadcastData;
    private EspUdpDriver udpDriver;  // ✅ Use a single instance of EspUdpDriver

    public static TextToSpeech textToSpeech;

    private Handler handler = new Handler();
    private Runnable checkConnectionRunnable;
    private ImageButton toggleTakeOffLand;
    private ToggleButton toggleAlthold;




    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (action == null) {
                return;
            }
            mBroadcastData.setValue(action);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ToggleButton toggleAlthold = findViewById(R.id.toggle_althold);
        if (toggleAlthold != null) {
            Log.d("DEBUG", "✅ toggle_Althold found in layout.");

            toggleAlthold.setOnClickListener(v -> {
                Log.d("BUTTON-CLICK", "Button clicked manually.");
                althold_1(v);
            });
        } else {
            Log.e("DEBUG", "❌ toggle_Althold NOT FOUND. Check layout file loaded.");
        }


        // Initialize LiveData
        mBroadcastData = new MutableLiveData<>();

        // Register Wi-Fi State Broadcast Receiver
        IntentFilter filter = new IntentFilter(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        registerReceiver(mReceiver, filter);

        // ✅ Initialize the UDP driver
        udpDriver = new EspUdpDriver(this);


        ////*********************** Speak function (voice)***********************************************///


        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    textToSpeech.setLanguage(Locale.ENGLISH);
                }
            }
        });


    }


    public static void speak(String message) {
        if (textToSpeech != null) {
            textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    ////******************************************** END  ****************************************************///
    boolean isFlying = false;

   // private ImageButton toggleTakeOffLand;

    @Override
    protected void onStart() {
        super.onStart();

        toggleTakeOffLand = findViewById(R.id.toggle_takeoff_land);

      toggleAlthold = findViewById(R.id.toggle_althold);

        toggleAlthold.setOnCheckedChangeListener((buttonView, isChecked) -> {
            althold_1(buttonView);
        });

        checkConnectionRunnable = new Runnable() {
            @Override
            public void run() {
                boolean isConnected = EspUdpDriver.isDroneConnected();

                toggleTakeOffLand.setEnabled(isConnected);
                toggleTakeOffLand.setAlpha(isConnected ? 1f : 0.5f);

                handler.postDelayed(this, 1000);
            }
        };

        handler.postDelayed(checkConnectionRunnable, 1000);

        toggleTakeOffLand.setOnClickListener(v -> {
            // Toggle by checking current icon
            ImageButton button = (ImageButton) v;
            int currentDrawableId = (Integer) button.getTag();

            if (currentDrawableId == R.drawable.ic_takeoff) {
                // Show land icon after takeoff
                button.setImageResource(R.drawable.ic_land);
                button.setTag(R.drawable.ic_land);
                takeoff(v);
            } else {
                // Show takeoff icon after land
                button.setImageResource(R.drawable.ic_takeoff);
                button.setTag(R.drawable.ic_takeoff);
                land();
            }
        });

        // Set initial tag
        toggleTakeOffLand.setTag(R.drawable.ic_takeoff);
    }


    ////*********************** Land function ***********************************************///

    public void land() {
        Log.d("BUTTON-CLICK", "Land Button Pressed");

        byte[] landCommand = new byte[]{(byte) 0x71, (byte) 0x13, (byte) 0x11, (byte) 0x00};  // AltHold OFF

        StringBuilder hexString = new StringBuilder();
        for (byte b : landCommand) {
            hexString.append(String.format("%02X ", b));
        }

        Toast.makeText(this, "📡 Sending LAND command...", Toast.LENGTH_SHORT).show();
        Log.d("UDP-SEND", "Sending LAND Data (HEX): " + hexString.toString());

        new Thread(() -> {
            try {
                String DRONE_IP = DEVICE_ADDRESS;
                int DRONE_PORT = DEVICE_PORT;

                initializeUdpSocket();

                InetAddress droneAddress = InetAddress.getByName(DRONE_IP);
                DatagramPacket packet = new DatagramPacket(landCommand, landCommand.length, droneAddress, DRONE_PORT);

                udpSocket.send(packet);
                Log.d("UDP-SEND", "✅ LAND UDP Data Sent Successfully (HEX): " + hexString.toString());

               if (EspUdpDriver.ack_land()){

                   Log.d("LAND-ACK","land message"+EspUdpDriver.ack_land());
                   speak("Land Completed");
               }
               else {
                   speak("ACK not Receivedar");
               }

            } catch (Exception e) {
                Log.e("LAND-ACK", "❌ Error Sending LAND UDP Data: " + e.getMessage());
            }
        }).start();
    }

    ////******************************************** END  ****************************************************///



    ////*********************** Take off/land ***********************************************///


    public void takeoff(View view) {
        Log.d("BUTTON-CLICK", "Takeoff Button Pressed");

        byte[] takeoffCommand = new byte[]{(byte) 0x71, (byte) 0x13, (byte) 0x11, (byte) 0x01};  // AltHold ON

        StringBuilder hexString = new StringBuilder();
        for (byte b : takeoffCommand) {
            hexString.append(String.format("%02X ", b));
        }

        Toast.makeText(this, "📡 Sending TAKEOFF command...", Toast.LENGTH_SHORT).show();
        Log.d("UDP-SEND", "Sending TAKEOFF Data (HEX): " + hexString.toString());

        new Thread(() -> {
            try {
                String DRONE_IP = DEVICE_ADDRESS;
                int DRONE_PORT = DEVICE_PORT;

                initializeUdpSocket();

                InetAddress droneAddress = InetAddress.getByName(DRONE_IP);
                DatagramPacket packet = new DatagramPacket(takeoffCommand, takeoffCommand.length, droneAddress, DRONE_PORT);

                udpSocket.send(packet);
                Log.d("UDP-SEND", "✅ TAKEOFF UDP Data Sent Successfully (HEX): " + hexString.toString());

                if (EspUdpDriver.ack_take_off()){

                    Log.d("UDP-SEND","Taske off message"+EspUdpDriver.ack_take_off());
                    speak("take off initiated");
                }

            } catch (Exception e) {
                Log.e("UDP-SEND", "❌ Error Sending TAKEOFF UDP Data: " + e.getMessage());
            }
        }).start();
    }


    ////******************************************** END  ****************************************************///


    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(checkConnectionRunnable);
    }





    ////*********************** Althold function ***********************************************///

    private boolean althold = true; // ✅ Start with AltHold mode as default

    public void althold_1(View view) {
        Log.d("BUTTON-CLICK", "AltHold Toggle Pressed");

        ToggleButton toggle = (ToggleButton) view;
        boolean isSportsMode = toggle.isChecked(); // ✅ true when brown (Sports), false when white (AltHold)

        byte[] altholdOn = new byte[]{(byte) 0x71, (byte) 0x13, (byte) 0x22, (byte) 0x01};  // AltHold ON
        byte[] altholdOff = new byte[]{(byte) 0x71, (byte) 0x13, (byte) 0x22, (byte) 0x00}; // AltHold OFF

        byte[] messageToSend = isSportsMode ? altholdOff : altholdOn;
        String statusMessage = isSportsMode ? "📡 Switching to Sports Mode..." : "📡 Enabling Altitude Hold Mode...";

        // ✅ Update state
        althold = !isSportsMode;

        StringBuilder hexString = new StringBuilder();
        for (byte b : messageToSend) {
            hexString.append(String.format("%02X ", b));
        }

        Toast.makeText(this, statusMessage, Toast.LENGTH_SHORT).show();
        Log.d("UDP-SEND", statusMessage + " Data (HEX): " + hexString.toString());

        new Thread(() -> {
            try {
                String DRONE_IP = DEVICE_ADDRESS;
                int DRONE_PORT = DEVICE_PORT;

                initializeUdpSocket();

                InetAddress droneAddress = InetAddress.getByName(DRONE_IP);
                DatagramPacket packet = new DatagramPacket(messageToSend, messageToSend.length, droneAddress, DRONE_PORT);

                udpSocket.send(packet);
                Log.d("UDP-SEND", "✅ UDP Data Sent Successfully (HEX): " + hexString.toString());

                speak(isSportsMode ? "Sports Mode" : "Altitude Hold Mode");

            } catch (Exception e) {
                Log.e("UDP-SEND", "❌ Error Sending UDP Data: " + e.getMessage());
            }
        }).start();
    }


    ////******************************************** END  ****************************************************///

    private DatagramSocket udpSocket;

    private void initializeUdpSocket() {
        try {
            if (udpSocket == null || udpSocket.isClosed()) {
                udpSocket = new DatagramSocket();
            }
        } catch (Exception e) {
            Log.e("UDP", "Socket Initialization Error: " + e.getMessage());
        }
    }

    ////*********************** ARM/Disarm ***********************************************///

    private boolean arm_state = false;

    public void arm(View view) {

        EspUdpDriver.ack_isArmed();
        Log.d("ARM_ACK", "ack" + EspUdpDriver.ack_isArmed());
        Log.d("BUTTON-CLICK", "ARM Button Pressed");


        showAssistantMessage("ARM Ganesh " );


        byte[] arm = new byte[]{(byte) 0x71, (byte) 0x13, (byte) 0x33, (byte) 0x01};
        byte[] disarm = new byte[]{(byte) 0x71, (byte) 0x13, (byte) 0x33, (byte) 0x00};

        byte[] messageToSend;
        String statusMessage;
        boolean willArm;

        if (!EspUdpDriver.isDroneConnected()) {
            Log.d("ARM_ACK", "❌ Drone is DISCONNECTED — forcing ARM ON");
            messageToSend = arm;
            statusMessage = "📡 Drone disconnected. Forcing ARM ON...";
            willArm = true;
        } else {
            Log.d("ARM_ACK", "🚀 Drone is CONNECTED");

            willArm = !arm_state;
            messageToSend = willArm ? arm : disarm;
            statusMessage = willArm ? "📡 Sending Arm command..." : "📡 Sending Disarm command...";
            arm_state = willArm;
        }

        StringBuilder hexString = new StringBuilder();
        for (byte b : messageToSend) {
            hexString.append(String.format("%02X ", b));
        }

        Toast.makeText(this, statusMessage, Toast.LENGTH_SHORT).show();
        Log.d("ARM_ACK", statusMessage + " Data (HEX): " + hexString.toString());

        new Thread(() -> {
            try {
                String DRONE_IP = DEVICE_ADDRESS;
                int DRONE_PORT = DEVICE_PORT;

                initializeUdpSocket();

                InetAddress droneAddress = InetAddress.getByName(DRONE_IP);
                DatagramPacket packet = new DatagramPacket(messageToSend, messageToSend.length, droneAddress, DRONE_PORT);

                udpSocket.send(packet);
                Log.d("ARM_ACK", "✅ UDP Data Sent Successfully (HEX): " + hexString.toString());

                // 🔊 Speak based on actual command sent
                speak(willArm ? "Armed" : "Disarmed");

                if (willArm) {
                    if (EspUdpDriver.ack_isArmed()) {
                        Log.d("ARM_ACK", "✅ ARM initiated");
                        speak("ARM initiated");
                    }
                } else {
                    if (EspUdpDriver.ack_dis_Armed()) {
                        Log.d("ARM_ACK", "✅ DisARM completed");
                        speak("DisARM completed");
                    } else {
                        Log.d("ARM_ACK", "❌ DisARM not completed");
                        speak("DisARM not completed");
                    }
                }

            } catch (Exception e) {
                Log.e("ARM_ACK", "❌ Error Sending UDP Data: " + e.getMessage());
            }
        }).start();
    }



    ////******************************************** END  ****************************************************///

    public void showAssistantMessage(final String message) {
        runOnUiThread(() -> {
            // Make assistant image visible
            ImageView assistantImage = findViewById(R.id.assistantImage);
            if (assistantImage != null) {
                assistantImage.setVisibility(View.VISIBLE);
            }

            // Inflate popup layout
            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View popupView = inflater.inflate(R.layout.custom_popup, null);

            // Set popup message
            TextView popupMessage = popupView.findViewById(R.id.popupMessage);
            popupMessage.setText(message);

            // Create popup window
            final PopupWindow popupWindow = new PopupWindow(
                    popupView,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    true
            );

            // Show popup at bottom-right, safely
            if (assistantImage != null) {
                popupWindow.showAsDropDown(assistantImage, -150, -250);
            } else {
                popupWindow.showAtLocation(findViewById(android.R.id.content), Gravity.BOTTOM | Gravity.END, 16, 16);
            }

            // Auto-dismiss after 3 seconds
            new Handler().postDelayed(() -> {
                if (popupWindow.isShowing()) {
                    popupWindow.dismiss();
                }
            }, 3000);
        });
    }







    @Override
    protected void onDestroy() {

        // 🔊 Shut down TextToSpeech
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }

        // 📡 Unregister Wi-Fi broadcast receiver
        unregisterReceiver(mReceiver);

        // 🔌 Disconnect UDP driver
        if (udpDriver != null) {
            udpDriver.disconnect();
        }

        // ✅ Call parent class destroy method once
        super.onDestroy();
    }


    public void observeBroadcast(LifecycleOwner owner, Observer<String> observer) {
        mBroadcastData.observe(owner, observer);
    }

    public void removeBroadcastObserver(Observer<String> observer) {
        mBroadcastData.removeObserver(observer);
    }


    public void showLogFileLocation() {
        TelemetryLogger logger = new TelemetryLogger(this);
        Toast.makeText(this, "Log file: " + logger.getLogFilePath(), Toast.LENGTH_LONG).show();
    }


}
