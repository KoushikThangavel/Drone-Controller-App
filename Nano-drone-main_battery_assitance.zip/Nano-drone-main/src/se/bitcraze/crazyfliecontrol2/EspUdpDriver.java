package se.bitcraze.crazyfliecontrol2;

import static se.bitcraze.crazyfliecontrol2.EspActivity.speak;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.util.Log;

import androidx.lifecycle.Observer;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import se.bitcraze.crazyflie.lib.crtp.CrtpDriver;
import se.bitcraze.crazyflie.lib.crtp.CrtpPacket;




public class EspUdpDriver extends CrtpDriver {
    private static final String TAG = "EspUdpDriver";

    static final int APP_PORT = 2399;
    static final int DEVICE_PORT = 2390;
    static final String DEVICE_ADDRESS = "192.168.43.42";

    private volatile boolean mConnectMark = false;
    private volatile DatagramSocket mSocket;
    private volatile ReceiveThread mReceiveThread;
    private volatile PostThread mPostThread;

    private final EspActivity mActivity;
    private final BlockingQueue<CrtpPacket> mInQueue;
    private final WifiManager mWifiManager;

    // Correct placement of global flags inside EspUdpDriver
    private static volatile boolean wifiReady = false;
    private static volatile boolean socketReady = false;
    private static boolean mIsArmed;

    private static boolean mIsdis_Armed;

    private static boolean mIs_take_off;
    //private static boolean mIs_land;


    private static volatile boolean mIs_land = false;


    // Public accessor for other classes
    public static boolean isDroneConnected() {
        return wifiReady && socketReady;
    }

    private final Observer<String> mObserver = new Observer<String>() {
        @Override
        public void onChanged(String s) {
            int networkId = mWifiManager.getConnectionInfo().getNetworkId();
            if (networkId == -1) {
                wifiReady = false;
                disconnect();
                notifyConnectionLost("No SoftAP connection");
            } else {
                wifiReady = true;
                if (mConnectMark) {
                    mConnectMark = false;
                    try {
                        InetAddress deviceAddress = InetAddress.getByName(DEVICE_ADDRESS);
                        mSocket = new DatagramSocket(null);
                        mSocket.setReuseAddress(true);
                        mSocket.bind(new InetSocketAddress(APP_PORT));

                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                            ConnectivityManager cm = (ConnectivityManager) mActivity.getSystemService(Context.CONNECTIVITY_SERVICE);
                            for (Network network : cm.getAllNetworks()) {
                                NetworkInfo networkInfo = cm.getNetworkInfo(network);
                                if (networkInfo != null
                                        && networkInfo.getType() == ConnectivityManager.TYPE_WIFI
                                        && networkInfo.isConnected()
                                        && networkInfo.getExtraInfo() != null
                                        && networkInfo.getExtraInfo().contains("ESP-DRONE_E86BEACF31B9")) {
                                    try {
                                        network.bindSocket(mSocket);
                                        Log.d(TAG, "Socket successfully bound to Drone Wi-Fi");
                                    } catch (IOException e) {
                                        Log.e(TAG, "Failed to bind socket to drone Wi-Fi", e);
                                    }
                                    break;
                                }
                            }
                        }

//                        mReceiveThread = new ReceiveThread(mSocket);
//                        mReceiveThread.setPacketQueue(mInQueue);
//                        mReceiveThread.start();

                        mReceiveThread = new ReceiveThread(mSocket, mActivity);
                        mReceiveThread.setPacketQueue(mInQueue);
                        mReceiveThread.start();

                        mPostThread = new PostThread(mSocket, deviceAddress);
                        mPostThread.start();

                        socketReady = true;
                        notifyConnected();
                    } catch (IOException e) {
                        if (mSocket != null) {
                            mSocket.close();
                            mSocket = null;
                        }
                        mActivity.removeBroadcastObserver(mObserver);
                        socketReady = false;
                        notifyConnectionFailed("Create socket failed");
                    }
                }
            }
        }
    };


    public void onArmStatusChanged(boolean isArmed) {
        // Handle arm status change here
        Log.d("ARM_STATUS", "ARM status: " + isArmed);
        // You can forward this to other components as needed
    }

    public EspUdpDriver(EspActivity activity) {
        mActivity = activity;
        mWifiManager = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        mInQueue = new LinkedBlockingQueue<>();
    }


    public static synchronized boolean ack_isArmed() {
        boolean currentState = mIsArmed;
        mIsArmed = false;  // Reset after read
        return currentState;
    }



    public static synchronized boolean ack_dis_Armed() {
        boolean currentState = mIsdis_Armed;
        mIsdis_Armed = false;  // Reset after read
        return currentState;
    }



    public static synchronized boolean ack_take_off() {
        boolean currentState = mIs_take_off;
        mIs_take_off = false;  // Reset after read
        return currentState;
    }



    public static synchronized boolean ack_land() {
        boolean currentState = mIs_land;
        mIs_land = false;  // Reset after read
        return currentState;
    }



    @Override
    public void connect() throws IOException {
        Log.w(TAG, "Connect()");

        speak("nexus Drone connected");

        if (mSocket != null) {
            throw new IllegalStateException("Connection already started");
        }

        mConnectMark = true;
        notifyConnectionRequested();
        mActivity.observeBroadcast(mActivity, mObserver);
    }

    @Override
    public void disconnect() {
        speak("nexus Drone disconnected");

        mActivity.removeBroadcastObserver(mObserver);
        if (mSocket != null) {
            mSocket.close();
            mSocket = null;
            mReceiveThread.interrupt();
            mReceiveThread.setPacketQueue(null);
            mReceiveThread = null;
            mPostThread.interrupt();
            mPostThread = null;
            notifyDisconnected();
            ((MainActivity) mActivity).setBatteryLevel(-1.0f);

        }
    }


    @Override
    public boolean isConnected() {
        return mSocket != null && !mSocket.isClosed();
    }

    // ✅ Only here, at the EspUdpDriver level (not inside ReceiveThread)
    @Override
    public void notifyConnected() {
        super.notifyConnected();
        Log.d(TAG, "notifyConnected(): wifiReady=" + wifiReady + ", socketReady=" + socketReady);
    }

    @Override
    protected void notifyDisconnected() {
        super.notifyDisconnected();
        socketReady = false;
        Log.d(TAG, "notifyDisconnected(): wifiReady=" + wifiReady + ", socketReady=" + socketReady);
    }

    @Override
    protected void notifyConnectionLost(String reason) {
        super.notifyConnectionLost(reason);
        socketReady = false;
        Log.d(TAG, "notifyConnectionLost(): wifiReady=" + wifiReady + ", socketReady=" + socketReady);
    }

    @Override
    public void sendPacket(CrtpPacket packet) {
        if (mSocket == null || mPostThread == null) {
            return;
        }

        mPostThread.sendPacket(packet);
    }

    @Override
    public CrtpPacket receivePacket(int wait) {
        try {
            return mInQueue.poll(wait, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Log.w(TAG, "ReceivePacket Interrupted");
            return null;
        }
    }

    private static class PostThread extends Thread {
        private BlockingQueue<CrtpPacket> mmQueue = new LinkedBlockingQueue<>();
        private DatagramSocket mmSocket;
        private InetAddress mmDevAddress;

        PostThread(DatagramSocket socket, InetAddress devAddress) {
            mmSocket = socket;
            mmDevAddress = devAddress;
        }

        void sendPacket(CrtpPacket packet) {
            mmQueue.add(packet);
        }

        @Override
        public void run() {
            while (!mmSocket.isClosed() && !isInterrupted()) {
                try {
                    CrtpPacket packet = mmQueue.take();
                    byte[] data = packet.toByteArray();
                    byte[] buf = new byte[data.length + 1];
                    System.arraycopy(data, 0, buf, 0, data.length);
                    int checksum = 0;
                    for (byte b : data) {
                        checksum += (b & 0xff);
                    }
                    buf[buf.length - 1] = (byte) checksum;
                    Log.w(TAG, "run: PostData: " + Arrays.toString(buf));
                    DatagramPacket udpPacket = new DatagramPacket(buf, buf.length, mmDevAddress, DEVICE_PORT);
                    mmSocket.send(udpPacket);
                } catch (IOException e) {
                    Log.w(TAG, "sendPacket: IOException: " + e.getMessage());
                    mmSocket.close();
                    break;
                } catch (InterruptedException e) {
                    break;
                }
            }

            Log.d(TAG, "run: PostThread End");
        }
    }



    private static class ReceiveThread extends Thread {

        private DatagramSocket mmSocket;
        private BlockingQueue<CrtpPacket> mmQueue;
        private EspActivity mActivity;  // add a reference to your activity

        ReceiveThread(DatagramSocket socket, EspActivity activity) {
            mmSocket = socket;
            mActivity = activity;
        }
        void setPacketQueue(BlockingQueue<CrtpPacket> queue) {
            mmQueue = queue;
        }
        @Override
        public void run() {
            byte[] buf = new byte[1024];
            DatagramPacket udpPacket = new DatagramPacket(buf, buf.length);
            while (!mmSocket.isClosed() && !isInterrupted()) {
                try {
                    mmSocket.receive(udpPacket);

                    int len = udpPacket.getLength();
                    byte[] raw = Arrays.copyOf(udpPacket.getData(), len);

                    // RAW DATA PRINT

                    //Log.d("RAW","raw"+raw.toString());
                    //Log.d("HUDD", "ARM ACK: CD CC AC 41 86");

                    byte[] expectedRaw_1 = {(byte) 0xCD, (byte) 0xCC, (byte) 0xAC, (byte) 0x41, (byte) 0x86};

                    if (Arrays.equals(raw, expectedRaw_1)) {

                        mIsArmed = true;
                        // your logic here
                        Log.d("HUD", "ARM ACK: CD CC AC 41 86");

                        }

                    byte[] expectedRaw_2 = {(byte) 0xCD, (byte) 0xCC, (byte) 0xAC, (byte) 0x42, (byte) 0x87};

                    if (Arrays.equals(raw, expectedRaw_2)) {

                        mIsdis_Armed = true;
                        Log.d("HUD", "ARM ACK: CD CC AC 42 87");

                    }

                    byte[] expectedRaw_3 = {(byte) 0xCD, (byte) 0xCC, (byte) 0xAC, (byte) 0x43, (byte) 0x88};

                    if (Arrays.equals(raw, expectedRaw_3)) {

                        mIs_take_off = true;
                        Log.d("HUD", "ARM ACK: CD CC AC 43 88");

                    }

                    byte[] expectedRaw_4 = {(byte) 0xCD, (byte) 0xCC, (byte) 0xAC, (byte) 0x44, (byte) 0x67};

                    if (Arrays.equals(raw, expectedRaw_4)) {
                        mIs_land = true;
                        Log.d("HUD", "LAND ACK RECEIVED: CD CC AC 44 67");
                    }


                    // Logging received bytes
                    StringBuilder hex = new StringBuilder();
                    for (int i = 0; i < len; i++) {
                        hex.append(String.format("%02X ", raw[i]));
                    }
                    Log.d("RAW", "Received bytes: " + hex.toString());



                    // Check explicitly for battery packet type
                    if (!(len == 5
                            && (raw[0] & 0xFF) == 0x21
                            && (raw[1] & 0xFF) == 0xFF
                            && (raw[2] & 0xFF) == 0xFF
                            && (raw[3] & 0xFF) == 0x02
                            && (raw[4] & 0xFF) == 0x21)) {
                        // Identified battery packet (by starting bytes '73 68')
                        float voltage = ByteBuffer.wrap(raw, 0, 4)
                                .order(ByteOrder.LITTLE_ENDIAN)
                                .getFloat();
                        Log.d("ganesh", String.format("✅ Battery Voltage = %.2f V", voltage));

                        if (voltage== 0.00){
                            Log.d("ganesh","this waste data" +voltage);

                        }

                        else {
                            mActivity.runOnUiThread(() -> {
                                if (mActivity instanceof MainActivity) {
                                    ((MainActivity) mActivity).setBatteryLevel(voltage);
                                } else {
                                    Log.w("ganesh", "Activity is not MainActivity instance, cannot update battery UI");
                                }
                            });
                        }

                    }
                    else {
                        Log.d("ganesh", "❌ Skipped non-battery packet");
                    }

                } catch (IOException e) {
                    Log.e("ganesh", "IO exception: " + e.getMessage());
                    break;
                }
            }
        }






        // helper to convert 4 bytes (little‑endian) into float

    }
}

















